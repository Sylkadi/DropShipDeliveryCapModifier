# Drop Ship Delivery Cap Modifier
#### Highly recommended to use on all clients.

Greatly increases dropship capacity, now allowing 999 to be bought in a single purchase and the dropship will be able to carry 9999 items at once.
Values can be changed in config.