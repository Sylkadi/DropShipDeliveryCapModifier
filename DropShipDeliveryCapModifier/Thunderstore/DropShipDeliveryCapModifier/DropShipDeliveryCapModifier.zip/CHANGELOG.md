# Changelog
<details>
	<summary>1.0.0</summary>

	- Introduced

</details>